<?php

namespace App\Http\Controllers\Api\v1;

use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Models\Log\LogAccess;
use App\Helpers\JwtAuthentication;
use App\Http\Controllers\Controller;
use App\Models\Data\UserSakip;
use App\Models\Sakip\MASTER\MasterOpd;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;

class AuthController extends Controller
{
    //
    protected $maxAttempts = 3; // 3;
    protected $decayMinutes = 2; // 2;
    public function authenticate(Request $request)
    {
        try{
            $credentials = $request->validate([
                'username' => ['required'],
                'password' => ['required'],
            ]);
    
            if (Auth::attempt($credentials)) {
                $usersakip = UserSakip::where(['user_id' => auth()->user()->id])->first();
                if(!$usersakip){
                    Auth::logout();
                    return response()->json([
                        'success' => false,
                        'message' => 'Username or password is incorrect.',
                        'code' => '404'
                    ], 401);
                }
                if(!Auth::user()->is_active){
                    Auth::logout();
                    return response()->json([
                        'success' => false,
                        'message' => 'Your account has been disabled.',
                    ], 401);
                }
                //get role
                $myroles = auth()->user()->roleplay->load('roles');
                $thisroles = $myroles->pluck('roles')->toArray();

                //get OPD
                $opd = null;
                if($usersakip->master_opd_id !== null){
                    $dataOpd = MasterOpd::find($usersakip->master_opd_id);
                    $opd = [
                        "id" => $dataOpd->id,
                        "nama_opd" => $dataOpd->nama_opd,
                        "alias_opd" => $dataOpd->alias_opd,
                        "ikd_opd_id" => $dataOpd->ikd_opd_id,
                        "simpeg_opd_id" => $dataOpd->simpeg_opd_id,
                        "simonev_opd_id" => $dataOpd->simonev_opd_id,
                        "kode_opd" => $dataOpd->kode_opd,
                        "kode_sub_opd" => $dataOpd->kode_sub_opd
                    ];
                }

                $level = $thisroles[0]['role_name'];
                $role = $thisroles[0]['id'];
                $jabatan = 'admin';
                $nip = '-';
                $gender = 'Laki-laki';
                // $getTokenIkd = $this->getIkdTokenAccess();
                $payload = [
                    "username" => auth()->user()->username,
                    "name" => auth()->user()->name,
                    "nip" => $nip,
                    "jabatan" => $jabatan,
                    "gender" => $gender,
                    "level" => $level,
                    "role" => $role,
                    "opd" => $opd,
                    // "ikdtoken" => $getTokenIkd['response']['access_token'] ?? "",
                ];

                $token_access = JwtAuthentication::create($payload);

                LogAccess::create([
                    "id"            => Str::uuid(),
                    "user"          => auth()->user()->username,
                    "ip_address"    => $request->ip(),
                    "user_agent"    => $request->header('User-Agent'),
                    "unix_time"     => time()
                ]);
    
                return response()->json([
                    'success' => true,
                    'token_access' => $token_access,
                    'message' => 'Login Success',
                ]);
            }
    
            return response()->json([
                'success' => false,
                'message' => 'Username or password is incorrect.',
            ], 401);
        }
        catch(\Exception $e)
        {
            return response()->json([
                'status' => 422,
                'message' => $e->getMessage()
            ],422);
        }
    }
    private function getIkdTokenAccess()
    {
        $params = [
            'grant_type' =>  "client_credentials",
            'client_id'     =>  env("IKD_CLIENT_ID", ""),
            'client_secret' => env('IKD_CLIENT_SECRET', ""),
            'scope'         => "*" 
        ];
        try {
            $response = Http::withoutVerifying()->asForm()->post(env('IKD_URL','') . '/oauth/token', $params);
            if($response->failed()){
                return array(
                    "error" => true,
                    "message" => "failed response from api"
                );
            }
            return array(
                "error" => false,
                "message" => "success",
                "response" => $response->json()
            );
        } catch (\Exception $e) {
            return array(
                "error" => true,
                "message" => $e->getMessage()
            );
        }
    }
}
