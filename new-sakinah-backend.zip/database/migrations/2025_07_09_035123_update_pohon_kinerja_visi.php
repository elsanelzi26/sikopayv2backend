<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
     /**
     * Run the migrations.
     *
     * @return void
     */

    public function up()
    {
        Schema::table('pohon_kinerja_visi', function(Blueprint $table)
        {
            $table->softDeletes();
        });
    }  

    /**
     * Reverse the migrations.
     *
     * @return void
     */

    public function down()
    {
        Schema::table('pohon_kinerja_visi', function(Blueprint $table)
        {
            $table->dropSoftDeletes();
        });
    }
};
