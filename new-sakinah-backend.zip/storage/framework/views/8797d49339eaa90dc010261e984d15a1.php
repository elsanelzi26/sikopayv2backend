<script>
    
    <?php if (isset($component)) { $__componentOriginal903a4bae8ceca5695c3f776b8cf73e5f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal903a4bae8ceca5695c3f776b8cf73e5f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app.datatable.datatablejs','data' => ['url' => env('APP_URL'). '/data/pegawai/datatable']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app.datatable.datatablejs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(env('APP_URL'). '/data/pegawai/datatable')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal903a4bae8ceca5695c3f776b8cf73e5f)): ?>
<?php $attributes = $__attributesOriginal903a4bae8ceca5695c3f776b8cf73e5f; ?>
<?php unset($__attributesOriginal903a4bae8ceca5695c3f776b8cf73e5f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal903a4bae8ceca5695c3f776b8cf73e5f)): ?>
<?php $component = $__componentOriginal903a4bae8ceca5695c3f776b8cf73e5f; ?>
<?php unset($__componentOriginal903a4bae8ceca5695c3f776b8cf73e5f); ?>
<?php endif; ?>
    function userCrud() {
        return {
            datatable: datatable(),
            openModal : false,
            formState : 'save',
            loadingState: false,
            idData : null,
            successAlert: {
                open: false,
                message: ''
            },
            failedAlert: {
                open: false,
                message: ''
            },
            confirmAdd(id = 0) {
                this.idData = id
                this.loadingState = true
                Swal.fire({
                title: 'Jadikan sebagai admin OPD?',
                text: "anda akan menjadikan pegawai ini sebagai admin perangkat daerah pada aplikasi sakinah!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        this.addData()
                    }
                    else this.loadingState = false
                })
            },
            
            async addData(id = 0) {
                try {
                    const response = await axios.post('<?php echo e(env('APP_URL')); ?>/data/adminopd', { user_id: this.idData });
                    if(response.status == 200) {
                    
                        Swal.fire({
                            icon: 'success',
                            title: response.data.message,
                            showConfirmButton: false,
                            timer: 1500
                        })

                        this.successAlert = {
                            open: true,
                            message: response.data.message
                        }
                        this.loadingState = false
                        window.location.href = '<?php echo e(env('APP_URL')); ?>/data/adminopd'
                    }
                } catch (e) {
                    this.loadingState = false
                    Swal.fire({
                        icon: 'error',
                        title: "something went wrong",
                        showConfirmButton: false,
                        timer: 1500
                    })
                }
            },
        }
    }
</script><?php /**PATH D:\kantor\sakinah\new-sakinah-backend\resources\views/app/data/adminopd/_inJsTambah.blade.php ENDPATH**/ ?>