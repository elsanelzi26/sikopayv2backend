<!doctype html>
<html>
<head>
  
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/tom-select.default.css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/font-awesome.css'); ?>
    
    <link rel="icon" type="image/png" href="<?php echo e(asset('images/985px-Laravel.svg.png')); ?>">
    <title><?php echo e(env("APP_NAME", "Laravel")); ?><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>
    <div>        
        <div x-data="{ sidebarOpen: false }" class="flex h-screen bg-gray-200">


            <?php echo $__env->make('layouts.app.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


            <div class="flex-1 flex flex-col overflow-hidden">

                <?php echo $__env->make('layouts.app.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <main class="flex-1 overflow-x-hidden overflow-y-auto bg-gray-200">
                    <div class="container mx-auto px-6 py-8">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </main>
            </div>
        </div>
    </div>

    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/sweetalert2.js'); ?>
    <?php echo $__env->yieldContent('_inJs'); ?>
</body>
</html><?php /**PATH D:\kantor\sakinah\new-sakinah-backend\resources\views/layouts/app/main.blade.php ENDPATH**/ ?>