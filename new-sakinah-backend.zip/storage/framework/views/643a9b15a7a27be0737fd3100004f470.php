<?php $__env->startSection('title', ' | Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<h3 class="text-gray-700 text-3xl font-medium">Dashboard</h3>
        
<div class="mt-4">
    <div class="flex flex-wrap -mx-6">
        <div class="w-full mt-6 px-6 xl:mt-0">
            <div class="flex flex-col items-left px-5 py-6 shadow-sm rounded-md bg-white">
                <h3 class="text-lg font-bold">Selamat Datang!</h3>
                <p class="font-bold"><?php echo e($user->name); ?>, anda login sebagai <?php echo e($current_role_name); ?></p>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kantor\sakinah\new-sakinah-backend\resources\views/dashboard/admin/_index.blade.php ENDPATH**/ ?>