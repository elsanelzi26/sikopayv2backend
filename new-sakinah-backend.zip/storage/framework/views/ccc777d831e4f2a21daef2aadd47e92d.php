<div :class="sidebarOpen ? 'block' : 'hidden'" @click="sidebarOpen = false" class="fixed z-20 inset-0 bg-black opacity-50 transition-opacity lg:hidden"></div>
        
<div :class="sidebarOpen ? 'translate-x-0 ease-out' : '-translate-x-full ease-in'" class="fixed z-30 inset-y-0 left-0 w-64 transition duration-300 transform bg-gray-900 overflow-y-auto lg:translate-x-0 lg:static lg:inset-0">
    <div class="flex items-center justify-center mt-8">
        <div class="flex items-center">
            <img src="<?php echo e(asset('images/985px-Laravel.svg.png')); ?>" class="mx-2 w-10 py-6" alt="">
            
            <span class="text-white text-2xl mx-2 font-semibold"><?php echo e(env("APP_NAME", "Dashboard")); ?></span>
        </div>
    </div>

<?php if (isset($component)) { $__componentOriginal90da1b02ef46ee39ceeebdcbade93b16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal90da1b02ef46ee39ceeebdcbade93b16 = $attributes; } ?>
<?php $component = App\View\Components\Menugenerator::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('menugenerator'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Menugenerator::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal90da1b02ef46ee39ceeebdcbade93b16)): ?>
<?php $attributes = $__attributesOriginal90da1b02ef46ee39ceeebdcbade93b16; ?>
<?php unset($__attributesOriginal90da1b02ef46ee39ceeebdcbade93b16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal90da1b02ef46ee39ceeebdcbade93b16)): ?>
<?php $component = $__componentOriginal90da1b02ef46ee39ceeebdcbade93b16; ?>
<?php unset($__componentOriginal90da1b02ef46ee39ceeebdcbade93b16); ?>
<?php endif; ?>
</div><?php /**PATH D:\kantor\sakinah\new-sakinah-backend\resources\views/layouts/app/partials/sidebar.blade.php ENDPATH**/ ?>